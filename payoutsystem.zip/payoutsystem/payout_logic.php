<?php
require 'db.php';
function distribute_commission($sale_user_id, $sale_amount, $conn) {
    $commission_levels = [1 => 10, 2 => 5, 3 => 3, 4 => 2, 5 => 1];
    $current_user_id = $sale_user_id;
    $level = 1;

    while ($level <= 5) {
        $result = $conn->query("SELECT parent_id FROM users WHERE id = $current_user_id");
        $row = $result->fetch_assoc();
        $parent_id = $row['parent_id'];

        if (!$parent_id) break;

        $commission = ($commission_levels[$level] / 100) * $sale_amount;
        $stmt = $conn->prepare("INSERT INTO commissions (user_id, from_user_id, level, commission) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiid", $parent_id, $sale_user_id, $level, $commission);
        $stmt->execute();

        $current_user_id = $parent_id;
        $level++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Welcome to the Commission System</h1>
            <a href="logout.php" class="logout-link">Logout</a>
        </header>
        <main>
            <p>Sale and commission distribution are successfully handled.</p>
        </main>
    </div>
</body>
</html>