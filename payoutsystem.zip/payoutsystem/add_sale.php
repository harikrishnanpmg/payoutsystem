<?php
require 'db.php';

function calculate_commissions($conn, $sale_id, $user_id, $sale_amount) {
    $levels = [10, 5, 3, 2, 1]; // Commission percentages for levels 1-5
    $current_user = $user_id;
    for ($level = 1; $level <= 5; $level++) {
        $query = $conn->prepare("SELECT parent_id FROM users WHERE id = ?");
        $query->bind_param("i", $current_user);
        $query->execute();
        $result = $query->get_result();
        $parent = $result->fetch_assoc();

        if (!$parent || !$parent['parent_id']) break;

        $current_user = $parent['parent_id'];
        $commission_amount = $sale_amount * ($levels[$level - 1] / 100);

        $insert_commission = $conn->prepare(
            "INSERT INTO commissions (user_id, from_user_id, level, commission) VALUES (?, ?, ?, ?)"
        );
        $insert_commission->bind_param("iiid", $current_user, $sale_id, $level, $commission_amount);
        $insert_commission->execute();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $sale_amount = $_POST['sale_amount'];

    $sale_query = $conn->prepare("INSERT INTO sales (user_id, amount) VALUES (?, ?)");
    $sale_query->bind_param("id", $user_id, $sale_amount);
    $sale_query->execute();
    $sale_id = $conn->insert_id;

    calculate_commissions($conn, $sale_id, $user_id, $sale_amount);
    echo "Sale added and commissions calculated!";
}
?>
<a href="dashboard.php" class="nav-link">Back to Dashboard</a>
                <a href="logout.php" class="logout-link">Logout</a>