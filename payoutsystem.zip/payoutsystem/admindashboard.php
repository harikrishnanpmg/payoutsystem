<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.html");
    exit;
}
$users_query = "SELECT * FROM users";
$users_result = $conn->query($users_query);
$sales_query = "SELECT * FROM sales";
$sales_result = $conn->query($sales_query);


$commissions_query = "SELECT * FROM commissions";
$commissions_result = $conn->query($commissions_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dashboard-container">
        <h1>Admin Dashboard</h1>
        <nav>
            <a href="logout.php">Logout</a>
        </nav>

        <section>
            <h2>Users</h2>
            <table>
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Parent ID</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($user = $users_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $user['id'] ?></td>
                            <td><?php echo $user['name'] ?></td>
                            <td><?php echo $user['email'] ?></td>
                            <td><?php echo $user['parent_id'] ?? 'None' ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>

        <section>
            <h2>Sales</h2>
            <table>
                <thead>
                    <tr>
                        <th>Sale ID</th>
                        <th>User ID</th>
                        <th>Sale Amount</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($sale = $sales_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $sale['id'] ?></td>
                            <td><?php echo $sale['user_id'] ?></td>
                            <td><?php echo number_format($sale['amount'], 2) ?></td>
                            <td><?php echo $sale['created_at'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>

        <section>
            <h2>Commissions</h2>
            <table>
                <thead>
                    <tr>
                        <th>Commission ID</th>
                        <th>User ID</th>
                        <th>From User</th>
                        <th>Level</th>
                        <th>Commission</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($commission = $commissions_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $commission['id'] ?></td>
                            <td><?php echo $commission['user_id'] ?></td>
                            <td><?php echo $commission['from_user_id'] ?></td>
                            <td><?php echo $commission['level'] ?></td>
                            <td><?php echo number_format($commission['commission'], 2) ?></td>
                            <td><?php echo $commission['created_at'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>
    </div>
</body>
</html>
