<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    
	$password = md5($_POST['password']);
    $parent_id = $_POST['parent_id'];

    $stmt = $conn->prepare("INSERT INTO users (name, email, password, parent_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $name, $email, $password, $parent_id);

    if ($stmt->execute()) {
        echo "Registration successful! <a href='index.html'>Login</a>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
