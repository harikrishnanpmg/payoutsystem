<?php
require 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}
$user_id = $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();

$sales = $conn->query("SELECT * FROM sales WHERE user_id = $user_id");
$commissions = $conn->query("SELECT * FROM commissions WHERE user_id = $user_id");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dashboard-container">
        <h1>Welcome, <?php echo $user['name'] ?></h1>
		<p><a href="logout.php">Logout</a>
		<p><a href="add_sale.html">Add Sale</a>
        <h2>Your Sales</h2>
        <table border="1">
            <tr>
                <th>Sale ID</th>
                <th>Amount</th>
                <th>Date</th>
            </tr>
            <?php while ($row = $sales->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $row['amount'] ?></td>
                <td><?php echo $row['created_at'] ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <h2>Your Commissions</h2>
        <table border="1">
            <tr>
                <th>From User</th>
                <th>Level</th>
                <th>Commission</th>
                <th>Date</th>
            </tr>
            <?php while ($row = $commissions->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['from_user_id'] ?></td>
                <td><?php echo $row['level'] ?></td>
                <td><?php echo $row['commission'] ?></td>
                <td><?php echo $row['created_at'] ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
