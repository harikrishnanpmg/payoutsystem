<?php
require 'db.php';


$query = "SELECT id, name FROM users";

$result = $conn->query($query);

$parents = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $parents[] = $row;
    }
}


header('Content-Type: application/json');
echo json_encode($parents);

$conn->close();
?>
